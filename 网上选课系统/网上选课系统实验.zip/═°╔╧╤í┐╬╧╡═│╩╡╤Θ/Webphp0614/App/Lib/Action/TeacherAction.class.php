<?php
//本类由系统自动生成，仅供测试用途
class TeacherAction extends Action {
    public function index(){
	/*$islogin = is_login('teacher');
	if(!$islogin['status']){
		$this->error($islogin['msg'],U('/Index/index'));}*/
	$this->display();
	}
}
?>

